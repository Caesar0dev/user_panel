"use strict";

const request = require("../request");
const Utils = require("../utils");
const URL = {
  PERSON_FIELDS: "https://api.pipedrive.com/v1/personFields?api_token=",
  PERSONS: "https://api.pipedrive.com/api/v1/persons/",
  ME: "https://api.pipedrive.com/v1/users/me?api_token=",
  USER: "https://api.pipedrive.com/v1/users/",
  TOKEN: "https://oauth.pipedrive.com/oauth/token",
  REVOKE: "https://oauth.pipedrive.com/oauth/revoke",
};

/**
 * Class for all api of pipedrive
 */
class PipeDrive {
  /**
   * Get my information
   * @param {string} token api token
   * @return my customer information
   */
  static getMyInfo(token) {
    return request(URL.ME + token);
  }
  // static getUserById(token, id) {
  //   // return request(URL.ME + token);
  //   return request(URL.USER + id + "?api_token=" + token);
  // }

  static getUserById(token, id, headers) {
    // return request(URL.USER + id);
    return request(URL.USER + id, "GET", {}, headers);
  }
  static revokeToken(refresh_token, headers) {
    console.log(
      "revoke token",
      refresh_token.toString().replace(/"/g, ""),
      "-------->",
      headers
    );
    return new Promise((resolve, reject) => {
      request(
        URL.REVOKE,
        "POST",
        {
          token: refresh_token.toString().replace(/"/g, ""),
          token_type_hint: "refresh_token",
        },
        headers
      )
        .then((token) => {
          resolve(token);
        })
        .catch((r) => reject(r));
    });
  }
  static getAccessToken(refresh_token, headers) {
    console.log(
      "refresh token in status",
      refresh_token.toString().replace(/"/g, ""),
      "-------->",
      headers
    );
    return new Promise((resolve, reject) => {
      request(
        URL.TOKEN,
        "POST",
        {
          grant_type: "refresh_token",
          refresh_token: refresh_token.toString().replace(/"/g, ""),
          // redirect_uri: "https://localhost:3000",
          redirect_uri: "https://server.certalink.com/user-panel",
        },
        headers
      )
        .then((token) => {
          resolve(token);
        })
        .catch((r) => reject(r));
    });
  }

  static getPersonById(id, token) {
    const headers = [["Authorization", "Bearer " + token]];
    return new Promise(async (resolve, reject) => {
      request(URL.PERSONS + id, "GET", {}, headers)
        .then((r) => {
          resolve(r.data);
        })
        .catch((r) => reject(r));
    });
  }
  /**
   *
   * @param {number} id
   * @param {string} field
   * @param {string} text
   */
  static updatePerson(id, token, field, fieldValue) {
    const headers = [
      ["Authorization", "Bearer " + socket.SESSION_VARS["access_token"]],
    ];

    return new Promise(async (resolve, reject) => {
      const data = {};
      data[field] = fieldValue;
      request(URL.PERSONS + id, "PUT", data, headers)
        .then((r) => {
          resolve(r.data);
          // console.log("after update", r.data);
        })
        .catch((r) => reject(r));
    });
  }
  static updateEmail(id, token, emails, status, data) {
    return new Promise(async (resolve, reject) => {
      // const email = {};
      const address = [];
      for (const mail of emails) {
        // zerobounce return invalid add "invalid" to email address.
        const email = {};
        let mail_value = "";
        let value = mail.value;
        if (value.indexOf("(") > 0)
          mail_value = value.substr(0, value.indexOf("("));
        else mail_value = value;
        console.log("mail_value status", data, mail_value, status[mail_value]);
        if (data.isUpdate_Invalid && status[mail_value] == "invalid") {
          if (data.isDelete_Invalid) email["value"] = "";
          else email["value"] = mail_value + "(" + status[mail_value] + ")";
        } else if (data.isUpdate_Spamtrap && status[mail_value] == "spamtrap") {
          console.log(
            "mail_value status",
            data.isDelete_Spamtrap,
            mail_value,
            status[mail_value]
          );
          if (data.isDelete_Spamtrap) email["value"] = "";
          else email["value"] = mail_value + "(" + status[mail_value] + ")";
        } else email["value"] = mail_value;

        email["label"] = mail.label;
        email["color"] = "red";
        address.push(email);
      }
      console.log("adress", address);
      const headers = [
        ["Content-Type", "application/json"],
        ["Accept", "application/json"],
        ["Authorization", "Bearer " + token],
      ];

      request(URL.PERSONS + id, "PUT", { email: address }, headers)
        .then((r) => {
          resolve(r.data);
          // console.log("after update", r.data);
        })
        .catch((r) => reject(r));
    });
  }

  /**
   * @summary get filed of person
   * @param {string} token
   */
  static personField(token) {
    return new Promise(async (resolve, reject) => {
      try {
        function search(fields) {
          try {
            if (fields) {
              for (const field of fields) {
                console.log("field name", field);
                if (field.name == "Email Validation") return field;
              }
            }
          } catch (e) {
            Utils.print.error("Error in PipeDrive:personFiled.", e);
          }
          return null;
        }

        // try to request with "GET" method
        // const retGet = request(URL.PERSON_FIELDS + token)
        // .then((r) => {
        //     resolve(r.data);
        // })
        // .catch((r) => reject(r));

        const retGet = await request(URL.PERSON_FIELDS + token);
        console.log("person custom filters", retGet);
        const evField = search(retGet.data);
        if (!evField) {
          //try to request with "POST"
          const retPost = request(URL.PERSON_FIELDS + token, "POST", {
            name: "Email Validation",
            field_type: "text",
          });
          resolve(retPost.data);
          console.log("no exist.", retPost.data);
        } else {
          console.log("exist", evField);
          resolve(evField);
        }
      } catch (e) {
        reject(e);
      }
    });
  }
}
module.exports = PipeDrive;
