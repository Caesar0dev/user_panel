"use strict";

const Stripe = require("../stripe");
const Utils = require("../utils");
const ZeroBounce = require("../zerobounce");
const PipeDrive = require("../pipedrive");
const MailClient = require("../email");
const { throws } = require("assert");
const { socket } = require("../utils");
const { SSL_OP_EPHEMERAL_RSA, EROFS } = require("constants");
const { updateCustomer } = require("../stripe");
const fs = require("fs");
const { personField } = require("../pipedrive");
const Global = require("../utils/global");
/**
 * @summary                 Event Listener for 'validate' message
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
module.exports = async function (socket, message) {
  if (!message.data) {
    Utils.socket.sendError(socket, "Invalid parameter. no data field.");
    return;
  }
  const validationCost = message.data.csv.split("\n").length - 1;
  try {
    // check credit balance of Customer.
    const current = await Stripe.getCustomerByEmail(
      // socket.SESSION_VARS["email"]
      message.data.email
    );
    console.log("current email after validate", current);

    const currentCredits = parseInt(current.metadata["Credit Balance"]);
    if (currentCredits < validationCost) {
      Utils.socket.sendError(
        socket,
        "You do not have enough credits to complete this check"
      );
      return;
    }

    // Upload emails list to ZeroBounce
    const ret = await ZeroBounce.sendCSV(
      "Email, First Name, Last Name" + message.data.csv
    );
    const zeroBounceRet = JSON.parse(ret);
    if (!zeroBounceRet.success) {
      Utils.socket.sendError(
        socket,
        // "Failed in handling [Validation Email List].\nPlease contact to your administrator."
        zeroBounceRet.message[0]
      );
      return;
    }
    // uploaded file id
    const fileId = zeroBounceRet.file_id;
    // fs.writeFile("client-server.txt", fileId, (err) => {
    //   if (err) console.log(err);
    //   console.log("Successfully Written to File.");
    // });

    // update client status
    Utils.socket.sendData(socket, "update", {
      state: "validating",
      validationMessage: "Start to validate email",
      socket_id: fileId,
    });

    // validate all
    Global.set("SOCKET_" + fileId, socket);
    // send file id to client...

    validateEmails(socket, fileId)
      .then(async (zeroFileInfo) => {
        // get success
        const completedDateTime = zeroFileInfo.upload_date.split(" ")[0];
        const updatedCustomer = await Stripe.updateCustomer(current.id, {
          ...current.metadata,
          "Credit Balance": currentCredits - validationCost,
          "File Id": fileId,
        });
        try {
          sendStatus(Global.get("SOCKET_" + fileId), updatedCustomer);
          // sendStatus(socket, updatedCustomer);
          await complete(
            Global.get("SOCKET_" + fileId),
            message,
            fileId,
            completedDateTime
          );
          // await complete(socket, message, fileId, completedDateTime);
        } catch (e) {
          Utils.print.log(e);
          Utils.socket.sendError(socket, "Error in completing validation.");
          // Utils.socket.sendError(Global.get(socket.SESSION_VARS['userid']), "Error in completing validation.");
        }
      })
      .catch((err) => {
        Utils.print.log("Validation ==> " + err);
        // Utils.socket.sendError(Global.get(socket.SESSION_VARS['userid']), err);
        Utils.socket.sendError(socket, err);
      });
  } catch (e) {
    Utils.print.error(e);
  }
};

/**
 * @summary        validate email, send the status
 * @param {socket} socket client connection socket
 * @param {number} fileId file id of zerobounce
 */
function validateEmails(socket, fileId) {
  // Global.set(socket.SESSION_VARS['userid'], socket)
  return new Promise(async (resolve, reject) => {
    // let timeout = 10000; // set timeout as 100 times
    let timeout = 1;
    while (timeout > 0) {
      // timeout--;
      timeout++;
      try {
        const fileInfo = JSON.parse(await ZeroBounce.getStatus(fileId));
        if (!fileInfo.success) {
          reject(
            "Error in validating emails!\nPlease contact to your administrator."
          );
          return;
        }
        console.log("validating file info", fileInfo);
        if (fileInfo.file_status === "Complete") {
          resolve(fileInfo);
          return;
        }

        // update client's status
        console.log("validating file info percent", fileId, fileInfo);
        Utils.socket.sendData(Global.get("SOCKET_" + fileId), "update", {
          // Utils.socket.sendData(socket, "update", {
          state: "validating",
          validateProcessing: {
            status: fileInfo.file_status,
            percent: fileInfo.complete_percentage,
          },
        });
        await Utils.time.sleep(1000);
      } catch (e) {
        reject(
          "Error in validating emails!\nPlease contact to your administrator."
        );
        return;
      }
    }
    reject("Timeout to validate emails!");
  });
}
/**
 *
 * @param {*} socket client socket
 * @param {*} message client message
 * @param {*} fileId zerobounce file id
 * @param {*} scanDate
 * @param {*} fileContent
 */
function complete(socket, message, fileId, scanDate) {
  return new Promise(async (resolve, reject) => {
    try {
      let f = await ZeroBounce.getFile(fileId);
      f = f.replace(/ZB /g, "");
      if (message.data.isDownload) Utils.socket.sendData(socket, "file", f);

      fs.writeFile("client-server.txt", f, (err) => {
        if (err) console.log(err);
        // console.log("Successfully Written to File.");
      });

      // const token = socket.SESSION_VARS["api_token"];
      const token = "cc638af3ea2783059aae7e32b5b80e34c1f0d1f4";
      const parsed = Utils.csv.parse(f);
      const fields = {};
      const email_status = {};
      let percent = 0;
      // console.log("parsed", parsed)
      let invalid_count = 0;

      console.log("update validating------>", message.data);

      for (let userId in message.data.idToEmail) {
        let finalText = "";
        email_status[userId] = {};
        for (const email of message.data.idToEmail[userId]) {
          let mail_value = "";
          if (email.indexOf("(") > 0)
            mail_value = email.substr(0, email.indexOf("("));
          else mail_value = email;

          // console.log("parsed status email ", parsed);
          if (parsed[mail_value] && parsed[mail_value].Email != "") {
            if (typeof parsed[mail_value].Status != "undefined")
              finalText += `${scanDate} - ${mail_value} - ${parsed[mail_value].Status}`;
            else console.log("parsed status email ", parsed);
            if (typeof parsed[mail_value]["Sub Status"] != "undefined") {
              finalText += ` (${parsed[mail_value]["Sub Status"]})`;
            }
            finalText += "\n";
            fields[userId] = finalText;
            // email_status[userId] = parsed[email].Status;

            email_status[userId][mail_value] = parsed[mail_value].Status;
            if (email_status[userId][mail_value] == "invalid") invalid_count++;
            console.log("invalid count--------->", invalid_count);
          }
        }
      }
      // console.log("email_status", email_status);
      // Add Email Status to Email address
      let ids = Object.keys(message.data.idToEmail);
      // if (ids.length < 10) await rateLimitedChanger(ids.length);
      // else await rateLimitedChanger(10);
      if (message.data.isUpdate_Spamtrap || message.data.isUpdate_Invalid) {
        await rateLimitedChanger(ids.length, message.data);
      }

      async function rateLimitedChanger(limit, data) {
        let i = limit;
        let requested = limit;
        while (i--) {
          Utils.socket.sendData(Global.get("SOCKET_" + fileId), "update", {
            state: "validating",
            validateProcessing: {
              status: "update_pipedrive",
              percent: Math.floor(((limit - i) / limit) * 100),
            },
          });
          let personId = ids.pop();
          //   Get person by ID
          let person_by_id = {};
          console.log("personId ", personId);
          // add invalid to email address.
          if (personId && personId != undefined) {
            try {
              console.log("personId ", personId);

              await PipeDrive.getPersonById(
                personId,
                socket.SESSION_VARS["access_token"]
              ).then((r) => {
                person_by_id = r;
              });

              let old_email = person_by_id["email"];
              console.log("old_email", personId, old_email);

              personId &&
                PipeDrive.updateEmail(
                  personId,
                  socket.SESSION_VARS["access_token"],
                  old_email,
                  email_status[personId],
                  data
                ).then((r) => {
                  fs.appendFile(
                    "update-email.txt",
                    old_email.value + "\r\n",
                    (err) => {
                      if (err) console.log(err);
                      // console.log("Successfully Written to File.");
                    }
                  );
                  if (!--requested && ids.length > 0) {
                    rateLimitedChanger(limit);
                  }
                });
            } catch (error) {
              console.log("personId error", personId, error);
            }
          }
        }
      }

      Utils.socket.sendData(Global.get("SOCKET_" + fileId), "update", {
        state: "finished",
      });
      MailClient.getInstance().send(
        message.data.email,
        "Hey " + socket.SESSION_VARS["name"] + "\n\n",
        "We have completed your email validation as requested." +
          " There were " +
          invalid_count +
          " invalid emails." +
          "If you have any questions please contact support@certalink.com."
      );

      resolve(true);
      return;
    } catch (e) {
      reject(e);
    }
  });
}
function sendStatus(socket, customer) {
  Utils.socket.sendData(socket, "status", {
    credits: customer.metadata["Credit Balance"],
    email: customer.email,
    history: customer.metadata,
  });
}
