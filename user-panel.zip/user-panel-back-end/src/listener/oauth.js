"use strict";

const Stripe = require("../stripe");
const Utils = require("../utils");
const request = require("../request");
const { Socket } = require("dgram");
const { CONFIG } = require("../../config");
/**
 * @summary                 Event Listener for 'paymentSuccess' message
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
let users = {};

// server app
const pipedriveAuthHeader = CONFIG.PIPEDRIVER_HEADER;
module.exports = async function (socket, message) {
  try {
    // console.log("oauth socket",socket)
    console.log("oauth message", message);
    users[socket.id] = {};
    let type = message.type,
      tabId = message.tabId || 0,
      params = message.data.params;
    oauth(socket, {
      type,
      id: socket.id,
      data: params,
    });
  } catch (e2) {
    Utils.socket.sendError(socket, e2);
  }
};

async function oauth(socket, params, callBack) {
  // console.log("oauth data", params);
  await request(
    "https://oauth.pipedrive.com/oauth/token",
    "POST",
    {
      grant_type: "authorization_code",
      code: params.data,
      // redirect_uri: "https://localhost:3000",
      redirect_uri: "https://server.certalink.com/user-panel",
    },
    pipedriveAuthHeader
    // redirect_uri: "https://localhost:3000",
    // redirect_uri: "https://server.certalink.com/user-panel",
  )
    .then((r) => {
      let token = JSON.parse(r);
      console.log("oauth token", token);
      params.token = token;
      getUserInfo(socket, token);
      //   introduction(params, callBack);
    })
    .catch((e) => {
      console.log("request error in oauth", e);
      Utils.socket.sendError(socket, e);
    });
}
async function getUserInfo(socket, params) {
  console.log("getUser in Params", params);
  const token_header = [["Authorization", "Bearer " + params.access_token]];
  console.log("token_header", "GET", token_header);
  await request(
    "https://api.pipedrive.com/v1/users/me",
    "GET",
    {},
    token_header
  )
    .then((r) => {
      //   resolve(r);
      console.log("refresh_token:params.refresh_token", params.refresh_token);
      Utils.socket.sendData(socket, "loggedin", {
        auth: r.data,
        access_token: params.access_token,
        refresh_token: params.refresh_token,
      });
      console.log("user info", r);
    })
    .catch((e) => {
      Utils.socket.sendData(socket, "error", { error: e });
      console.error("eror", e);
    });

  await request(
    "https://oauth.pipedrive.com/oauth/token",
    "POST",
    {
      grant_type: "refresh_token",
      refresh_token: params.refresh_token,
      redirect_uri: "https://server.certalink.com/user-panel",
      // redirect_uri: "https://localhost:3000",
    },
    pipedriveAuthHeader
    // redirect_uri: "https://localhost:3000",
    // redirect_uri: "https://server.certalink.com/user-panel",
  )
    .then((r) => {
      let token = JSON.parse(r);
      console.log("refresh token in oauth", token);
      // params.token = token;
      //   getUserById(socket, token);
    })
    .catch((e) => {
      console.log("request error in getuserinfo", e);
      Utils.socket.sendError(socket, e);
    });
}
