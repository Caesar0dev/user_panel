'use strict';

const Stripe = require('../stripe');
const Utils = require('../utils');

/**
 * @summary                 Event Listener for 'payment' message
 * @param {any}     socket  connected websocket
 * @param {any}     message
 */
module.exports = async function (socket, message) {
    try {
        const credits = parseInt(message.data.amount);
        const pricePlan = getPricePlanByCredits(credits);
        // const pricePlan = parseInt(message.data.amount)
        console.log('credits',credits)
        console.log('pricePlan',pricePlan)
        console.log('paymentIntent')
        console.log(credits * pricePlan.price * 100, credits.toString(), 'usd')
        if (pricePlan) {
            if(message.data.tax){
                const paymentIntent = await Stripe.createPaymentIntent( pricePlan.price * 100+ pricePlan.price * 10, credits.toString(), 'usd', message.data.tax);
                Utils.socket.sendData(socket, 'payment', { secret: paymentIntent.client_secret, tabId: message.data.tabId });
            }
            else{
                const paymentIntent = await Stripe.createPaymentIntent( pricePlan.price * 100, credits.toString(), 'usd', message.data.tax);
                Utils.socket.sendData(socket, 'payment', { secret: paymentIntent.client_secret, tabId: message.data.tabId });
            }
                
        } else {
            Utils.socket.sendError(socket, 'Invalid credits amount');
        }
    } catch (e) {
        Utils.print.error(e);
        Utils.socket.sendError(socket, e);
    }
};
const _pricePlans = {
    1000: { price: 8, description: "5K to 10K", dueTo: "40 minutes" },
    5000: { price: 39, description: "10K to 100K", dueTo: "40 minutes" },
    25000: { price: 159, description: "100K to 250K", dueTo: "40 minutes" },
};
function getPricePlanByCredits(credits) {
    for (const planIndex in _pricePlans) {
        if (planIndex == credits) {
            return _pricePlans[planIndex];
        }
    }
}
