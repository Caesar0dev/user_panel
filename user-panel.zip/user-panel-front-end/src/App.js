import React, { Component } from "react";
import { BrowserRouter, Switch, Route, Link } from "react-router-dom";

import "./App.css";
import Routes from "./routes";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import NavBar from "./components/header/Navbar";

import SocketClient from "./utils/socketClient";
import Footer from "./components/footer/Footer";
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      storage: 0,
      web3: null,
      accounts: null,
      incidents: null,
      crowdsale: null,
      fund: null,
    };
  }
  componentDidMount = () => {
    // console.log(this.webEth)
    // SocketClient.getInstance().connect(process.env.NODE_ENV === "development"?"ws://127.0.0.1:8888":'wss://server.certalink.com/user-panel');
    SocketClient.getInstance().connect(process.env.NODE_ENV === "development"?"ws://127.0.0.1:8888":'wss://server.certalink.com/ev_server');
    // SocketClient.getInstance().connect('wss://server.certalink.com/emailvalidator');
    // SocketClient.getInstance().connect('wss://server.certalink.com/ev_server');

  };

  render() {
    // const isOpen = true;
    // let content;
    // content = <NavBar />;
    return (
      <div>
        <NavBar />
        <main style={{minHeight:'80vh'}}>
          <Routes />
        </main>
        <Footer/>
      </div>
    );
  }
}

export default App;
