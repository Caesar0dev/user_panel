import React from "react";
//Routes
// import NotFound from './components/shared/NotFound'
import App from "./App";
import Home from "./components/home/index";
import Main from "./components/main";
import Profile from "./components/profile";
import About from "./components/about";
//React-router
import { Route, Switch, Redirect } from "react-router-dom";
const Routes = () => {
  return (
    <Switch>
      <Route path="/about" exact component={About} />
      {/* <Route path="pages/profile/" exact component={Profile} user={this.state.getThisUser} /> */}
      <Route path="/pages/profile/" exact component={Profile} />

      <Route path="/" exact component={Main} />
      <Redirect exact to="/" />

      {/* server    */}
      {/* <Route path="/user-panel" exact component={Main} />
      <Redirect exact to="/user-panel" /> */}
    </Switch>
  );
};
export default Routes;
