// import { initialState } from '../constants/initialState';
import { connect, useDispatch, useSelector } from "react-redux";
import SocketClient from "../utils/socketClient";
var loggedIn = localStorage.getItem("loggedIn");
// var stage = localStorage.getItem("stage");
var user = loggedIn ? JSON.parse(localStorage.getItem("user")) : {};
var status = loggedIn ? JSON.parse(localStorage.getItem("status")) : {};
var access_token = loggedIn
  ? JSON.parse(localStorage.getItem("access_token"))
  : "";
const initialState = {
  connection: false,
  code: "",
  //   loggedIn: false,
  //   user: '',
  credits: status ? status.credits : 0,
  loggedIn: loggedIn,
  user: user,
  status: status,
  access_token: access_token,
  stage: "selected",
  validateProcessing: {
    status: "Queued",
    percent: "0%",
  },
  error: "",
};

export const socket = (state = initialState, action) => {
  const { type, response } = action;
  switch (type) {
    case "SOCKET_CONNECTION":
      console.log("socket connect res", response);
      return {
        ...state,
        // socket: response,
        connection: response,
      };
    case "OAUTH_CODE":
      return {
        ...state,
        // socket: response,
        code: response,
      };
    case "SCANNING":
      localStorage.setItem("stage", "scanning");
      return {
        ...state,
        // socket: response,
        stage: localStorage.getItem("stage", "scanning"),
      };
    case "PAYMENT":
      return {
        ...state,
        // socket: response,
        payment_secret: response,
      };

    case "SET_TIME":
      console.log("timer", response);
      // if(response == "validating")
      //   localStorage.setItem("stage", response);
      localStorage.setItem("startTime", response);
      return {
        ...state,
        startTime: response,

        // stage: localStorage.getItem("stage")?localStorage.getItem("stage"):response,
      };

    case "SET_STAGE":
      console.log("update", response);
      // if(response == "validating")
      //   localStorage.setItem("stage", response);
      return {
        ...state,
        stage: response,
        // stage: localStorage.getItem("stage")?localStorage.getItem("stage"):response,
      };
    case "VALIDATE_PROCESS":
      if (response.validateProcessing) {
        console.log("validateProcessing-----", response);
        localStorage.setItem("stage", response.state);
        return {
          ...state,
          // socket: response,
          // stage: response.state,
          stage: localStorage.getItem("stage"),
          validateProcessing: response.validateProcessing,
        };
      }
    // else{
    //   console.log("updateProcessing-----", response);
    //   return {
    //     ...state,
    //     // socket: response,
    //     stage: response.state,
    //     updateProcessing: response.updateProcessing,
    //   };
    // }

    case "SET_VALIDATE":
      console.log("validate", response);
      return {
        ...state,
        scanned_persons: response.scanned_persons,
        scanned_emails: response.scanned_emails,
        csv: response.csv,
        idToEmail: response.idToEmail,
        email: response.email,
      };
    case "LOG_IN":
      loggedIn = localStorage.getItem("loggedIn");
      user = loggedIn ? JSON.parse(localStorage.getItem("user")) : {};
      access_token = loggedIn
        ? JSON.parse(localStorage.getItem("access_token"))
        : "";
      return {
        ...state,
        // loggedIn: true,
        // user: response.auth,
        // socket: response,
        loggedIn: loggedIn,
        user: user,
        access_token: access_token,
      };
    case "STATUS":
      status = loggedIn ? JSON.parse(localStorage.getItem("status")) : {};
      return {
        ...state,
        // loggedIn: true,
        // user: response.auth,
        // socket: response,
        credits: status.credits,
      };
    case "UPDATE_CREDIT":
      return {
        ...state,
      };
    case "ERROR":
      console.log("response ERROR", response.messages);
      return {
        ...state,
        error: response.messages,
      };
    case "INITILIZE_WEB3":
      return {
        ...state,
        web3: response,
      };
    case "WEB3_GET_ACCOUNTS":
      return {
        ...state,
        accounts: response,
      };
    default:
      return state;
  }
};
