import { combineReducers } from 'redux';
import {socket} from './socketReducer'
const rootReducer = combineReducers({
    socket: socket,
});

export default rootReducer;


