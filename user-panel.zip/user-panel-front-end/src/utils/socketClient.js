/**
 * Websocket client class to communicate with node socket server running at *.*.*.*:8888
 */

export default class SocketClient {
    /**
     * static get instance method in singleton class
     */
    static _inst = null;
    static getInstance() {
        if (!SocketClient._inst) SocketClient._inst = new SocketClient();
        return SocketClient._inst;
    }
    constructor() {
        console.log('Socket client is created.');
    }
    static EVENT = {
        OPEN: 'SOCKET_OPEN',
        CLOSE: 'SOCKET_CLOSED',
        ERROR: 'SOCKET_ERROR',
        MESSAGE: 'SOCKET_MESSAGE',
        LOGOUT: 'LOG_OUT', 
        LOGIN: 'LOG_IN'
    };

    isConnected = false;
    serverPath = '';
    keepConnection = true;
    callbacks = [];
    dispatch = null;

    initWithDispatch(dispatch) {
        this.dispatch = dispatch;
    }
    /**
     * @summary connect to websocket server.
     * @param {string} url
     */
    connect(url, keepConnection = true) {
        this.serverPath = url;
        this.keepConnection = keepConnection;
        if (this.socket && this.socket.readyState !== WebSocket.CLOSED) {
            console.log('Bad call to connect while client socket is running.');
            return;
        }
        try {
            this.socket = new WebSocket(url);
            this.socket.onopen = this.onOpen;
            this.socket.onerror = this.onError;
            this.socket.onclose = this.onClose;
            this.socket.onmessage = this.onMessage;
            
        } catch (e) {
            console.error('Error in connecting server.', e);
        }
    }
    /**
     * @summary         Make JSON from type and data, convert it to string and send to server.
     * @param {string} type
     * @param {string} data
     */
    send(type, data) {
        try {
            this.socket.send(JSON.stringify({ type, data }));
        } catch (e) {
            console.error('Error in sending data to server.', e);
        }
    }

      /**
     * @summary         add comma by 3 digitsr.
     * @param {number}   
     * @param {function} 
     */
    numberWithCommas(number) {
        if(number > 999)
            return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        else
            return number
    }
  
    /**
     * @summary         add event listener.
     * @param {string}   eventType
     * @param {function} callback
     */
    addEventListener(eventType, callback) {
        this.callbacks.push({ eventType, callback });
    }

    /**
     * @summary         remove event listener
     * @param {string}  eventType
     * @param {function} callback
     */
    removeEventListener(eventType, callback) {
        this.callbacks = this.callbacks.filter((record) => record.eventType !== eventType || record.callback !== callback);
    }
    /**
     * @summary         call every callback for specific event type. It will be called for all socket event
     * @param {string} eventType
     * @param {event} event
     */
    callProperCallback(eventType, event) {
        this.callbacks.forEach((record) => {
            if (record.eventType === eventType) record.callback(event);
        });
    }
    // Socket event listeners
    /**
     * @summary callback of socket "onopen" event
     * @param {*} event socket event
     */
    onOpen(event) {
        console.log('Socket is opend.', new Date().toLocaleTimeString());
        // setSocketConnection('true')
        SocketClient.getInstance().isConnected = true;
        SocketClient.getInstance().callProperCallback(SocketClient.EVENT.OPEN, event);
        SocketClient.getInstance().dispatch({type:'SOCKET_CONNECTION', response: SocketClient.getInstance().isConnected})
    }
    /**
     * @summary callback of socket "onopen" event
     * @param {*} event socket event
     */
    onError(event) {
        console.log('Socket error.');
        SocketClient.getInstance().isConnected = false;
        SocketClient.getInstance().callProperCallback(SocketClient.EVENT.ERROR, event);
        SocketClient.getInstance().dispatch({type:'SOCKET_CONNECTION', response: SocketClient.getInstance().isConnected})
    }
    /**
     * @summary callback of socket "onopen" event
     * @param {*} event socket event
     */
    onClose(event) {
        console.log('Socket is closed.');
        // alert('socket close')
        SocketClient.getInstance().isConnected = false;
        SocketClient.getInstance().dispatch({type:'SOCKET_CONNECTION', response: SocketClient.getInstance().isConnected})
        SocketClient.getInstance().callProperCallback(SocketClient.EVENT.CLOSE, event);
        // if keepConnection is true, it will try to reconnect on every time of socket close.

        if (SocketClient.getInstance().keepConnection)
            setTimeout(() => SocketClient.getInstance().connect(SocketClient.getInstance().serverPath, true), 5000);
    }
    /**
     * @summary callback of socket "onopen" event
     * @param {*} event socket event
     */
    onMessage(event) {
        console.log('Socket message.', SocketClient.EVENT.MESSAGE);
        SocketClient.getInstance().callProperCallback(SocketClient.EVENT.MESSAGE, event);
    }
}
