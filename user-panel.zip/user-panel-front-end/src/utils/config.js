exports.CONFIG = {
  VERSION: "0.1.0",
  HOST: "127.0.0.1",
  REDIRECT_URI:
    process.env.NODE_ENV === "development"
      ? "https://localhost:3000"
      : "https://server.certalink.com/user-panel",
  PIPEDRIVE_API_TOKEN: "cc638af3ea2783059aae7e32b5b80e34c1f0d1f4",
  ZEROBOUNCE_KEY: "2994e60cdf954aa4a943e28d3872226c",
  BULK_VALIDATION: 0,
  SINGLE_VALIDATION: 1,
  SCHEDULE_VALIDATION: 2,
  CREDITS: 3,
  ACCOUNT: 4,
  NEWS: 5,
  ACCOUNTDETAIL: 6,
  PRODUCT_EXPORT: 7,
  PRODUCT_IMPORT: 8,
};

// REDIRECT_URI:
// REDIRECT_URI:'https://localhost:3000'
