import React, { Component, useEffect, useState } from "react";
import "./styles.css";

import logo from "../../Certa-Logo-Web.png";
const NavBar = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  useEffect(() => {
    setLoggedIn(localStorage.getItem("loggedIn"));
  }, []);
  const logout = () => {
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("user");
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    localStorage.removeItem("socket_id");
    localStorage.removeItem("stage");
    localStorage.removeItem("status");
  };
  return (
    <nav className="navbar navbar-expand-lg navbar-default static-top">
      <div className="container">
        <a className="navbar-brand" href="#">
          <img src={logo} alt="" />
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarResponsive"
          aria-controls="navbarResponsive"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarResponsive">
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              {loggedIn ? (
                <a className="nav-link" href="">
                  Home
                </a>
              ) : (
                ""
              )}{" "}
            </li>

            {/* <li className="nav-item active">
              <a
                className="nav-link"
                href="https://certalink.com/help-center/"
                target="_blank"
              >
                Help Center
                <span className="sr-only">(current)</span>
              </a>
            </li> */}

            <li className="nav-item">
              {loggedIn ? (
                <a className="nav-link" href="" onClick={logout}>
                  Logout
                </a>
              ) : (
                ""
              )}
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
export default NavBar;
