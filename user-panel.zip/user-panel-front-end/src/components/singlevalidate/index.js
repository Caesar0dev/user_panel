import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";

import Loader from "react-loader-spinner";
import SocketClient from "../../utils/socketClient";
import Timer from "../timer";
// import "./style.css";
const Config = require("../../utils/config");
const SingleValidate = () => {
  const dispatch = useDispatch();
  const [email, setEamil] = useState("");
  const [response, setResponse] = useState({});
  const [loading, setLoading] = useState(false);
  const [refreshToken, setRefreshToken] = useState(false);
  const [contacts, setContacts] = useState([]);
  const [validated, setValidate] = useState(false);
  useEffect(() => {
    SocketClient.getInstance().send("status", {
      token: Config.CONFIG.PIPEDRIVE_API_TOKEN,
      id: socket.user.id,
      socket_id: localStorage.getItem("socket_id"),
      refresh_token: localStorage.getItem("refresh_token"),
    });
    if (refreshToken) {
      setRefreshToken(false);
      fetch(`https://api.pipedrive.com/v1/persons/search?term=` + email, {
        method: "GET",
        mode: "cors",
        headers: {
          Authorization:
            "Bearer " +
            localStorage.getItem("access_token").toString().replace(/"/g, ""),
        },
      })
        .then((r) => r.json())
        .then((data) => {
          if (
            data.success == "false" &&
            data.error == "Invalid token: access token is invalid"
          )
            setRefreshToken(true);
          else if (data.success == true && data.data.items.length > 0) {
            console.log("contacts in useeffect--------->", data.data.items);
            setContacts(data.data.items);
          }
        });
    }
  }, [refreshToken]);
  const singleValidation = () => {
    if (email === "") return;
    setValidate(false);
    setContacts([]);
    setResponse({});
    setLoading(true);
    fetch(
      `https://api.zerobounce.net/v2/validate?api_key=${Config.CONFIG.ZEROBOUNCE_KEY}&email=${email}&ip_address=`,
      {
        method: "GET",
        mode: "cors",
      }
    )
      .then((r) => r.json())
      .then((data) => {
        console.log("single validate ", data);
        setResponse(data);
        setLoading(false);
        // Object.keys(data).map((key, value) => (
        //   console.log("object value", key, data[key])
        // ))
        // setFilters((state) => [{ id: 0, name: "All Contacts" }, ...state]);
        // collectEmails(data.data);
      });
    fetch(
      `https://api.pipedrive.com/v1/persons/search?term=` +
        email +
        "&fields=email&exact_match=true",
      {
        method: "GET",
        mode: "cors",
        headers: {
          Authorization:
            "Bearer " +
            localStorage.getItem("access_token").toString().replace(/"/g, ""),
        },
      }
    )
      .then((r) => r.json())
      .then((data) => {
        console.log("search persons", data);
        if (
          data.success == "false" &&
          data.error == "Invalid token: access token is invalid"
        )
          setRefreshToken(true);
        else if (data.success == true && data.data.items.length > 0) {
          console.log("contacts--------->", data.data.items);
          setContacts(data.data.items);
        } else {
        }
        setValidate(true);
      });
  };
  const socket = useSelector((state) => state.socket);

  return (
    <div className="divSection">
      <div className="mt-2 box p-2">
        <b className="page_heading">Single Email Validation</b>
        <div className="box mt-4">
          {/* <label for="email">Email Address:</label> */}
          <p>Enter an email address to validate</p>
          <input
            className="input"
            id="email"
            onChange={(e) => {
              setEamil(e.target.value);
            }}
          />
          <button
            className={loading ? "button button--loading" : "button"}
            onClick={singleValidation}
          >
            <span class="button__text">Go!</span>
          </button>
        </div>

        {response ? (
          <div className="mt-4 singleValidation">
            {Object.keys(response).map((key, value) => (
              <div>
                {response[key] == null ? (
                  ""
                ) : (
                  <p key={value} style={{ fontSize: "17px" }}>
                    <span
                      className="singleValidationKey"
                      style={{ textDecoration: "underline" }}
                    >
                      {key}:
                    </span>
                    <span
                      className="singleValidationValue"
                      style={{ color: "green" }}
                    >
                      &nbsp;{response[key]}
                    </span>
                  </p>
                )}
              </div>
            ))}
          </div>
        ) : (
          ""
        )}
        {contacts.length ? (
          <div className="mt-4 singleValidation">
            <p style={{ fontSize: "17px" }}>
              This email is in Pipedrive associated with the following contacts:
            </p>

            {contacts.map((contact) => (
              <div>
                <a
                  href={`https://certa.pipedrive.com/person/` + contact.item.id}
                  target="_blank"
                >
                  <p
                    className="singleValidationContact"
                    key={contact.item.id}
                    style={{ fontSize: "17px" }}
                  >
                    <span style={{ textDecoration: "underline" }}>
                      {contact.item.name}
                      {contact.item.organization &&
                      contact.item.organization.name
                        ? " (" + contact.item.organization.name + ")"
                        : ""}
                    </span>
                  </p>
                </a>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-4 singleValidation">
            <p style={{ fontSize: "17px" }}>
              {validated ? "This email address was not found in Pipedrive" : ""}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SingleValidate;
