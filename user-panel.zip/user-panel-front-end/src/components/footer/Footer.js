import React, { Component, useEffect, useState } from "react";
import "./styles.css";

const Footer = () => {
  return (
    <footer>
      <div className="footer" style={{ background: "#e9eaee" }}>
        <div>© Copyright 2018 - 2020 Certa Pty Ltd</div>

        <div>
          <a target="_blank" href="https://certalink.com/terms-of-service">
            Terms of Service{" "}
          </a>
          |{" "}
          <a target="_blank" href="https://certalink.com/privacy-policy">
            Privacy Policy
          </a>
        </div>
      </div>
    </footer>
  );
};
export default Footer;
