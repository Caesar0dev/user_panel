import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";

import SocketClient from "../../utils/socketClient";
import Credit from "../credit";
import "../styles/style.css";
import Loader from "react-loader-spinner";
import Operation from "../operation/index";
import logo from "../../login.png";
import SingleValidate from "../singlevalidate";
import Account from "../account";
import NewsPage from "../news";
import ScanSelected from "../bulkscan";
const Config = require("../../utils/config");

const Home = ({
  page,
  openBulkPage,
  openSinglePage,
  handleCredit,
  handleAccount,
}) => {
  const [loginattempt, setLoginattempt] = useState(false);
  const socket = useSelector((state) => state.socket);
  const dispatch = useDispatch();

  var isLoggingIn = document.location.href.indexOf("code=") > -1;
  useEffect(() => {
    if (!socket.loggedIn && isLoggingIn) {
      if (document.location.href.includes("code=")) {
        var params = document.location.href.split("code=")[1].split("#")[0];

        // if url has code, display the dot loader
        setLoginattempt(true);
        dispatch({ type: "OAUTH_CODE", response: params });
        (async () => {
          await SocketClient.getInstance().send("oauth", {
            params: params,
            tabId: "",
          });
          // alert("send status after oauth");
          // await SocketClient.getInstance().send("status", {
          //   token: Config.CONFIG.PIPEDRIVE_API_TOKEN,
          //   id: socket.user.id,
          //   socket_id: localStorage.getItem("socket_id"),
          //   refresh_token:localStorage.getItem('refresh_token')
          // });
        })();
      }
    } else if (socket.loggedIn) {
      // // alert()
      // SocketClient.getInstance().send("status", {
      //   token: api_token,
      //   id: socket.user.id,
      // });
    }
    if (socket && socket.isLoggingIn) {
      console.log("send status");
      (async () => {
        await SocketClient.getInstance().send("status", {
          token: Config.CONFIG.PIPEDRIVE_API_TOKEN,
          id: socket.user.id,
          socket_id: localStorage.getItem("socket_id"),
          refresh_token: localStorage.getItem("refresh_token"),
        });
      })();
      window.location = Config.Config.REDIRECT_URI;
    }
  }, []);

  const oauthLoader = () => {
    setLoginattempt(true);
  };

  return (
    <div className="container">
      {/* <div className="section">
        <h1 className="section-title"> Validate Emails</h1>
      </div> */}

      <div className="agileits-top">
        {socket.loggedIn ? (
          <div>
            <div className="row">
              <div className="col-sm-4">
                <Operation
                  openSinglePage={openSinglePage}
                  openBulkPage={openBulkPage}
                  handleCredit={handleCredit}
                  handleAccount={handleAccount}
                />
              </div>
              <div className="offset-sm-1 col-sm-7">
                {/* {page ? <Scan /> : <Credit />} */}
                {page == Config.CONFIG.BULK_VALIDATION && (
                  <ScanSelected></ScanSelected>
                )}
                {page == Config.CONFIG.SINGLE_VALIDATION && (
                  <SingleValidate></SingleValidate>
                )}
                {page == Config.CONFIG.CREDITS && <Credit></Credit>}
                {page == Config.CONFIG.ACCOUNT && (
                  <Account handleCredit={handleCredit}></Account>
                )}
                {/* {page == Config.CONFIG.NEWS && <NewsPage></NewsPage>} */}
              </div>
            </div>
          </div>
        ) : (
          <div>
            {loginattempt ? (
              <div style={{ display: "flex" }}>
                <p style={{ margin: "auto 20px ", fontSize: "22px" }}>
                  {" "}
                  Connecting to Pipedrive
                </p>
                <span>
                  <Loader
                    type="ThreeDots"
                    color="#2BAD60"
                    height="30"
                    width="60"
                  />
                </span>
              </div>
            ) : (
              <div className="box">
                <div className="box mt-4 row">
                  <div className="col-sm-2">
                    <img
                      src={logo}
                      style={{ height: "150px", width: "150px" }}
                    ></img>
                  </div>
                  <div className="col-sm-6">
                    <div className="row" style={{ width: "250px" }}>
                      <p className="loginTitle">
                        Login and connect to Pipedrive
                      </p>
                    </div>
                    <div className="row mt-4">
                      <a
                        style={{ float: "right" }}
                        target="blank"
                        href={
                          process.env.NODE_ENV === "development"
                            ? "https://oauth.pipedrive.com/oauth/authorize?client_id=dee49ef30753f12f&redirect_uri=https://localhost:3000"
                            : "https://oauth.pipedrive.com/oauth/authorize?client_id=67c7097db1c334ad&redirect_uri=https://server.certalink.com/user-panel"
                        }
                      >
                        <button className="loginButton" onClick={oauthLoader}>
                          Login with Pipedrive
                        </button>
                      </a>
                    </div>
                  </div>
                  <div className="col-sm-4"></div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;

// href="https://oauth.pipedrive.com/oauth/authorize?client_id=67c7097db1c334ad&amp;redirect_uri=https://localhost:3000"

// href="https://oauth.pipedrive.com/oauth/authorize?client_id=67c7097db1c334ad&amp;redirect_uri=https://server.certalink.com"
