import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";

import SocketClient from "../utils/socketClient";
import Home from "./home";
import "./styles/style.css";
const Config = require("../utils/config");
// const api_token = "cc638af3ea2783059aae7e32b5b80e34c1f0d1f4";

const Main = ({ props }) => {
  const dispatch = useDispatch();
  const [page, setPage] = useState(0);

  useEffect(() => {
    // Send the dispatch object to SocketClient Class
    console.log("refresh SOCKET MESSAGE");
    SocketClient.getInstance().initWithDispatch(dispatch);
    SocketClient.getInstance().addEventListener(
      SocketClient.EVENT.MESSAGE,
      function (event) {
        const message = JSON.parse(event.data);
        console.log("SOCKET MESSAGE", message);
        switch (message.type) {
          case "error":
            dispatch({ type: "ERROR", response: message.data });
            break;
          case "payment":
            // message.data.secret
            console.log("PAYMENT", message.data.secret);
            dispatch({ type: "PAYMENT", response: message.data.secret });
            break;
          case "logout":
            console.log("logout logout");
            localStorage.removeItem("loggedIn");
            localStorage.removeItem("user");
            localStorage.removeItem("access_token");
            localStorage.removeItem("status");
            localStorage.removeItem("refresh_token");
            window.location.reload();
            break;
          case "loggedin":
            console.log("loggedin", message.data.auth);
            localStorage.setItem("user", JSON.stringify(message.data.auth));
            localStorage.setItem(
              "access_token",
              JSON.stringify(message.data.access_token)
            );
            localStorage.setItem(
              "refresh_token",
              JSON.stringify(message.data.refresh_token)
            );
            localStorage.setItem("loggedIn", true);
            dispatch({ type: "LOG_IN", response: message.data });
            window.location = Config.CONFIG.REDIRECT_URI;
            break;
          case "testing":
            console.log("testing", message.data);
            // chrome.storage.local.set(message.data);
            break;
          case "status":
            console.log("case status", message.data);
            localStorage.setItem("status", JSON.stringify(message.data));
            if (
              message.data.access_token &&
              message.data.access_token !== "undefined"
            )
              localStorage.setItem(
                "access_token",
                JSON.stringify(message.data.access_token)
              );
            dispatch({ type: "STATUS", response: message.data });
            break;
          case "update":
            if (message.data.socket_id) {
              localStorage.setItem("socket_id", message.data.socket_id);
            }
            console.log("update status", message.data);
            if (message.data.state == "payment")
              SocketClient.getInstance().send("status", {
                token: Config.CONFIG.PIPEDRIVE_API_TOKEN,
                id: socket.user.id,
                socket_id: localStorage.getItem("socket_id"),
                refresh_token: localStorage.getItem("refresh_token"),
              });
            // dispatch({ type: "UPDATE_CREDIT", response: message.data.credits });
            else if (message.data.validateProcessing) {
              dispatch({ type: "VALIDATE_PROCESS", response: message.data });
            } else
              dispatch({ type: "SET_STAGE", response: message.data.state });

            break;
          case "file": {
            // create virtual download link
            console.log(message.data);
            const url =
              "data:text/csv;charset=utf-8," + encodeURIComponent(message.data);
            const virtualDowloadLink = document.createElement("a");
            virtualDowloadLink.href = url;
            virtualDowloadLink.download = socket.user.company_name + ".csv";
            document.body.appendChild(virtualDowloadLink);
            // make click
            virtualDowloadLink.click();
            // delete
            setTimeout(() => {
              document.body.removeChild(virtualDowloadLink);
            }, 0);
          }
          // case "export":
          //   {
          //     // create virtual download link
          //     console.log(message.data);
          //     const url =
          //       "data:text/csv;charset=utf-8," +
          //       encodeURIComponent(message.data);
          //     const virtualDowloadLink = document.createElement("a");
          //     virtualDowloadLink.href = url;
          //     virtualDowloadLink.download = socket.user.company_name + ".csv";
          //     document.body.appendChild(virtualDowloadLink);
          //     // make click
          //     virtualDowloadLink.click();
          //     // delete
          //     setTimeout(() => {
          //       document.body.removeChild(virtualDowloadLink);
          //     }, 0);
          //   }
          //   break;
        }
      }
    );
  }, []);
  const openBulkPage = () => {
    setPage(Config.CONFIG.BULK_VALIDATION);
  };
  const openSinglePage = () => {
    setPage(Config.CONFIG.SINGLE_VALIDATION);
  };
  const openCreditPage = () => {
    setPage(Config.CONFIG.CREDITS);
  };
  const openAccountPage = () => {
    setPage(Config.CONFIG.ACCOUNT);
  };
  const openProductExportPage = () => {
    setPage(Config.CONFIG.PRODUCT_EXPORT);
  };
  const openProductImportPage = () => {
    setPage(Config.CONFIG.PRODUCT_IMPORT);
  };

  const socket = useSelector((state) => state.socket);
  // if (socket.loggedIn) {
  //       console.log("socket connection in main.js", socket.connection, { token: api_token, id:socket.user.id })
  //       SocketClient.getInstance().send("status", { token: api_token, id:socket.user.id });
  //     console.log("socket connection", socket);
  // }
  return (
    <div className="container">
      <div className="main-w3layouts wrapper">
        {socket.connection ? (
          <Home
            page={page}
            openBulkPage={openBulkPage}
            openSinglePage={openSinglePage}
            handleCredit={openCreditPage}
            handleAccount={openAccountPage}
            openProductExportPage={openProductExportPage}
            openProductImportPage={openProductImportPage}
          />
        ) : (
          <h1 style={{ fontSize: "22px" }}></h1>
        )}
      </div>
    </div>
  );
};

export default Main;
