import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";

import Loader from "react-loader-spinner";
import SocketClient from "../../utils/socketClient";
// import "./style.css";

const Timer = () => {
  const dispatch = useDispatch();
  const [timer, setTimer] = useState(0);
  useEffect(() => {
    setInterval(() => {
      setTimer((timer) => timer + 1);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);
  const formatTime = (timer) => {
    const getSeconds = `0${timer % 60}`.slice(-2);
    const minutes = `${Math.floor(timer / 60)}`;
    const getMinutes = `0${minutes % 60}`.slice(-2);
    const getHours = `0${Math.floor(timer / 3600)}`.slice(-2);

    return `${getHours} : ${getMinutes} : ${getSeconds}`;
  };
  const socket = useSelector((state) => state.socket);

  return (
    <>
      {formatTime(timer)}
    </>
  );
};

export default Timer;
