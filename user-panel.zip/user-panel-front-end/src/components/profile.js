import React, { Component } from "react";
// import RepList from " ./rep/rep-list.js"
// import RepList from "./rep/reps"

class Profile extends Component {
  constructor(props) {
    super(props);
  }

   render() {
    return (
      <div>
        profile page

      </div>
    )

  }
}

export default Profile;