import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import SocketClient from "../../utils/socketClient";
// import "./style.css";
import Scanning from "../scanning";
import Validating from "../validating/index";
const Config = require("../../utils/config");

const ScanSelected = ({ props }) => {
  const dispatch = useDispatch();
  const [filters, setFilters] = useState([]);
  const [disable, setDisable] = useState("true");
  // setFilters((state) => [{ id: 0, name: "All Contacts" }]);
  // const [status, setStatus] = useState('');
  const [idOfFilter, setIdOfFilter] = useState(0);

  var isRedirect = document.location.href.indexOf("code=") > -1;

  const GetTime = () => {
    var date, TimeType, hour, minutes, seconds, fullTime;
    // Creating Date() function object.
    date = new Date();

    // Getting current hour from Date object.
    hour = date.getHours();

    // Checking if the Hour is less than equals to 11 then Set the Time format as AM.
    if (hour <= 11) {
      TimeType = "AM";
    } else {
      // If the Hour is Not less than equals to 11 then Set the Time format as PM.
      TimeType = "PM";
    }

    // IF current hour is grater than 12 then minus 12 from current hour to make it in 12 Hours Format.
    if (hour > 12) {
      hour = hour - 12;
    }

    // If hour value is 0 then by default set its value to 12, because 24 means 0 in 24 hours time format.
    if (hour == 0) {
      hour = 12;
    }

    // Getting the current minutes from date object.
    minutes = date.getMinutes();

    // Checking if the minutes value is less then 10 then add 0 before minutes.
    if (minutes < 10) {
      minutes = "0" + minutes.toString();
    }
    fullTime =
      hour.toString() + ":" + minutes.toString() + ":" + TimeType.toString();
    console.log("time------->", fullTime);
    return fullTime;
  };
  useEffect(() => {
    /** Get Filters from Pipedrive */
    if (socket.loggedIn && !isRedirect) {
      fetch(`https://api.pipedrive.com/v1/filters?type=people`, {
        method: "GET",
        mode: "cors",
        headers: {
          Authorization:
            "Bearer " +
            localStorage.getItem("access_token").toString().replace(/"/g, ""),
        },
      })
        .then((r) => r.json())
        .then((data) => {
          console.log("get filters with access_token", data.data);
          // setFilters((state) =>[data.data, ...state]);
          if (data.data) {
            setFilters(data.data);
            setFilters((state) => [{ id: 0, name: "All Contacts" }, ...state]);
            setDisable("false");
          }
        })
        .catch((e) => {
          console.log("single err ", e);
        });
      SocketClient.getInstance().send("status", {
        token: Config.CONFIG.PIPEDRIVE_API_TOKEN,
        id: socket.user.id,
        socket_id: localStorage.getItem("socket_id"),
        refresh_token: localStorage.getItem("refresh_token"),
        test: 44444444444444444444444444,
      });
    }
  }, []);

  const socket = useSelector((state) => state.socket);

  function handleChange(e) {
    setIdOfFilter(e.target.value);
  }
  let scanStatus = {
    message: "starting scaning",
    scanned: 0,
    emails: 0,
    invalid_emails: 0,
  };
  const scanSelected = () => {
    /**Click Scan Selected Button, Current Stage is scanning */
    dispatch({ type: "SET_STAGE", response: "scanning" });
    dispatch({ type: "SET_TIME", response: GetTime() });

    // state is scanning emails
  };
  let filterList = "";
  if (filters.length) {
    filterList =
      filters.length > 0 &&
      filters.map((item, i) => {
        return (
          <option key={i} value={item.id}>
            {item.name}
          </option>
        );
      }, this);
  }
  function BulkScan() {
    return (
      <div className="mt-2 box p-2">
        <b className="page_heading">Bulk Email Validation </b>
        <br />

        <b className="sub_heading">Step 1</b>
        {socket.error !== "" && (
          <>
            <br /> <p style={{ color: "red" }}>{socket.error}</p>
          </>
        )}
        <div>
          Choose "All Contacts" or a Pipedrive filter. We will then scan the
          list for duplicates.
        </div>
        <div className="box mt-4">
          <select className="mr-1" value={idOfFilter} onChange={handleChange}>
            {filterList}
          </select>
          <button className="button ml-1" onClick={scanSelected}>
            Go!
          </button>
        </div>
      </div>
    );
  }
  function BulkSelected() {
    return (
      <div className="mt-2 box p-2">
        <b className="page_heading">Bulk Email Validation </b>
        <br />

        <b className="sub_heading">Step 1</b>
        {socket.error !== "" && (
          <>
            <br /> <p style={{ color: "red" }}>{socket.error}</p>
          </>
        )}
        <br />
        <div>
          Choose "All Contacts" or a Pipedrive filter. We will then scan the
          list for duplicates.
        </div>
        <div className="box mt-4">
          <select className="mr-1" value={idOfFilter} onChange={handleChange}>
            {filterList}
          </select>
          <button className="button ml-1" onClick={scanSelected}>
            Go!
          </button>
        </div>
        <Scanning idOfFilter={idOfFilter} />
      </div>
    );
  }
  return (
    <div className="divSection">
      {/* {socket.error !=="" && <p style={{color:'red'}}>{socket.error}</p>} */}

      {/* Redirect Scanning page with Filter ID when button clicked(stage is scanning)  */}
      {/* {socket.stage === "scanning" && <Scanning idOfFilter={idOfFilter} />} */}
      {socket.stage === "scanning" && <BulkSelected />}

      {/* Redirect Scanning page with Filter ID when button clicked(stage is scanning)  */}
      {socket.stage === "validating" && <Validating />}

      {/* Redirect Scanning page with Filter ID when button clicked(stage is scanning)  */}
      {socket.stage === "finished" && <Validating />}

      {/*In Scanning, redirect to Validate after scan_finished. */}
      {socket.stage === "scan_finished" && <Scanning />}

      {/* current page, stage  */}
      {socket.stage === "selected" && <BulkScan />}

      {/* not email found show the error(red) messge */}
      {socket.stage === "email_not_found" && (
        <div className="mt-2 box p-2">
          <b className="page_heading">Bulk Email Validation </b>
          <br />

          <b className="sub_heading">Step 1</b>
          {socket.error !== "" && (
            <>
              <br /> <p style={{ color: "red" }}>{socket.error}</p>
            </>
          )}
          <div>
            Choose "All Contacts" or a Pipedrive filter. We will then scan the
            list for duplicates.
          </div>
          <div className="box mt-4">
            <select className="mr-1" value={idOfFilter} onChange={handleChange}>
              {filterList}
            </select>
            <button className="button ml-1" onClick={scanSelected}>
              Go!
            </button>
            <br />
            <div className="mt-4" style={{ color: "red" }}>
              No matching contacts found.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default ScanSelected;
