import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";

// import CheckIcon from "../styles/check.svg";

const ValidatingStatus = ({ logoP, logoD, done, status, message }) => {
  const dispatch = useDispatch();
  const logo = status + ".png";
  useEffect(() => {}, []);
  const validate = () => {
    // SocketClient.getInstance().send('validate', { csv, email: message.data, idToEmail });
  };
  // const socket = useSelector((state) => state.socket);
  // console.log("socket finish catch", socket);
  return (
    <div className="number_wrapper" style={{ position: "relative" }}>
      {/* <img src={require(logo)}></img> */}
      {done ? (
        <>
          <img className="number_disks" src={logoD}></img>
          {message.length > 0 ? (
            <div className="validationStep">
              <span>
                <p className="validationStepText" style={{ font: "bold" }}>
                  {status}
                </p>
                <p className="validationStepText">{message}</p>
              </span>
            </div>
          ) : (
            ""
          )}
        </>
      ) : (
        <img className="number_disks" src={logoP}></img>
      )}
    </div>
  );
};

export default ValidatingStatus;
