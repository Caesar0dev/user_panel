import React, { Component, useEffect, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
// const stripePromise = loadStripe(
//   "pk_test_51GsJaTENKR3DelSmluW4kP0QbP1fldW9sVMuegxwyMbmBt7yduvqb3Y0uvvNyZv9Da3gLS5o8iv25LSGvGOWYxDk009lbSNn9f"
// );
const stripePromise = loadStripe("pk_live_3LlO84dRneuvLT4cRNrqNI1a00zer0Zu1K");

const NewsPage = ({ props }) => {
  return (
    <div className="divSection">
      <div className="mt-2 box p-2">
        <b>Latest news</b>
        <div className="mt-4">
          <iframe
            src="https://server.certalink.com/upload/"
            title="Latest News"
          ></iframe>
        </div>
      </div>
    </div>
  );
};

export default NewsPage;
