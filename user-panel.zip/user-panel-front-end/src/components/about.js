import React, {Component} from 'react'
const About =({props}) => {


    return (
          <p>
          </p>
    )
}
export default About