import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import { Elements, CardElement } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import SocketClient from "../../utils/socketClient";
import CheckoutForm from "../checkoutform";
import "./style.css";

// const stripePromise = loadStripe(
//   "pk_test_51GsJaTENKR3DelSmluW4kP0QbP1fldW9sVMuegxwyMbmBt7yduvqb3Y0uvvNyZv9Da3gLS5o8iv25LSGvGOWYxDk009lbSNn9f"
// );
const stripePromise = loadStripe(
  "pk_live_51GsJaTENKR3DelSmxeZtQ8jKcNxnGVvE0RzAg93XFPvtmAvGWoSy4833C5PIFRvju23nJp8ITLDibJcHkJuGTkKN00Wysz41Q0"
);

const Credit = ({ props }) => {
  const dispatch = useDispatch();
  const socket = useSelector((state) => state.socket);

  const [tax, setTax] = useState(false);
  useEffect(() => {
    console.log("socket.user", socket.user);
    setTax(socket.user.locale.toLowerCase() == "en_au" ? true : false);
  }, []);

  const ELEMENTS_OPTIONS = {
    fonts: [
      {
        cssSrc: "https://fonts.googleapis.com/css?family=Roboto",
      },
    ],
  };
  return (
    <div className="divSection">
      <div className="mt-2 box p-2">
        <b className="page_heading">Purchase Credits</b>
        <div className="mt-4">
          <Elements stripe={stripePromise} options={ELEMENTS_OPTIONS}>
            {/* <CheckoutForm amount={amount} price={price} tax={tax} /> */}
            <CheckoutForm tax={tax} />
          </Elements>
        </div>
      </div>
    </div>
  );
};

export default Credit;
