import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import SocketClient from "../../utils/socketClient";
// import "./style.css";
import Validating from "../validating";

const Validate = () => {
  const dispatch = useDispatch();
  const [isDownload, setIsDownload] = useState(false);
  const [isUpdate_Spamtrap, setIsUpdate_Spamtrap] = useState(false);
  const [isDelete_Spamtrap, setIsDelete_Spamtrap] = useState(false);
  const [isUpdate_Invalid, setIsUpdate_Invalid] = useState(false);
  const [isDelete_Invalid, setIsDelete_Invalid] = useState(false);
  useEffect(() => {
    //  alert(scanedPerson);
    /**
     * if not found emails redirect scan seleted page with email not found message
     */
    if (socket.scanned_emails == 0)
      dispatch({ type: "SET_STAGE", response: "email_not_found" });
  }, []);
  const validate = () => {
    console.log(
      "isDownload",
      isDownload,
      "isUpdate_Spamtrap",
      isUpdate_Spamtrap,
      "isDelete_Spamtrap",
      isDelete_Spamtrap,
      "isUpdate_Invalid",
      isUpdate_Invalid,
      "isDelete_Invalid",
      isDelete_Invalid
    );
    SocketClient.getInstance().send("validate", {
      csv: socket.csv,
      email: socket.email,
      idToEmail: socket.idToEmail,
      scanned_persons: socket.scanned_persons,
      isDownload: isDownload,
      isUpdate_Spamtrap: isUpdate_Spamtrap,
      isDelete_Spamtrap: isDelete_Spamtrap,
      isDelete_Invalid: isDelete_Invalid,
      isUpdate_Invalid: isUpdate_Invalid,
    });
  };
  const handleScanData = (value, type = 0) => {
    console.log("handleScanData : ----- ", value, type);
  };

  const socket = useSelector((state) => state.socket);
  return (
    <div className="mt-2 box p-2">
      {/* <h3>Scanned</h3> */}
      <b className="page_heading">Bulk Email Validation</b>
      <br />
      <b className="sub_heading">Step 2</b>
      {socket.error !== "" && (
        <>
          <br /> <p style={{ color: "red" }}>{socket.error}</p>
        </>
      )}
      <br />
      <p>
        We have scanned{" "}
        {SocketClient.getInstance().numberWithCommas(socket.scanned_persons)}{" "}
        contacts with{" "}
        {SocketClient.getInstance().numberWithCommas(socket.scanned_emails)}{" "}
        unique email addresses.
      </p>
      <br />
      <div className="box">
        {/* Default switch  */}
        <div className="row">
          <div className="col-sm-7">
            <p className="processing_options" style={{ fontWeight: "bold" }}>
              Processing Options
            </p>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label">Download ResultFile</p>
          </div>
          <div className="col-sm-5">
            <label className="switch">
              <input
                className="switch-input"
                type="checkbox"
                checked={isDownload}
                onClick={() => setIsDownload(!isDownload)}
              />
              <span className="switch-label" data-on="On" data-off="Off"></span>
              <span className="switch-handle"></span>
            </label>
          </div>
        </div>
      </div>
      <div className="box ">
        <div className="row">
          <div className="col-sm-7">
            <p className="label_heading" style={{ fontWeight: "bold" }}>
              Invalid emails
            </p>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label">Update Pipedrive</p>
          </div>

          <div className="col-sm-5">
            <label className="switch">
              <input
                className="switch-input"
                type="checkbox"
                checked={isUpdate_Invalid}
                onClick={() => setIsUpdate_Invalid(!isUpdate_Invalid)}
              />
              <span className="switch-label" data-on="On" data-off="Off"></span>
              <span className="switch-handle"></span>
            </label>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label ml-3">Append invalid addresses</p>
          </div>

          <div className="col-sm-5">
            <input
              type="radio"
              name="pipRadio"
              checked={!isDelete_Invalid}
              onClick={() => setIsDelete_Invalid(false)}
              disabled={isUpdate_Invalid ? false : true}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label ml-3">Delete invalid addresses</p>
          </div>

          <div className="col-sm-5">
            <input
              type="radio"
              name="pipRadio"
              checked={isDelete_Invalid}
              onClick={() => setIsDelete_Invalid(true)}
              disabled={isUpdate_Invalid ? false : true}
            />
          </div>
        </div>
      </div>
      <div className="box ">
        <div className="row">
          <div className="col-sm-7">
            <p className="label_heading" style={{ fontWeight: "bold" }}>
              Spamtrap emails
            </p>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label">Update Pipedrive</p>
          </div>

          <div className="col-sm-5">
            <label className="switch">
              <input
                className="switch-input"
                type="checkbox"
                checked={isUpdate_Spamtrap}
                onClick={() => setIsUpdate_Spamtrap(!isUpdate_Spamtrap)}
              />
              <span className="switch-label" data-on="On" data-off="Off"></span>
              <span className="switch-handle"></span>
            </label>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label ml-3">Append spamtrap addresses</p>
          </div>

          <div className="col-sm-5">
            <input
              type="radio"
              name="pipeRadio"
              checked={!isDelete_Spamtrap}
              onClick={() => setIsDelete_Spamtrap(false)}
              disabled={isUpdate_Spamtrap ? false : true}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-sm-7">
            <p className="label ml-3">Delete spamtrap addresses</p>
          </div>

          <div className="col-sm-5">
            <input
              type="radio"
              name="pipeRadio"
              checked={isDelete_Spamtrap}
              onClick={() => setIsDelete_Spamtrap(true)}
              disabled={isUpdate_Spamtrap ? false : true}
            />
          </div>
        </div>
      </div>
      <div className="box mt-4"></div>
      <div className="box mt-4">
        <button
          className="button ml-3"
          onClick={validate}
          disabled={
            !isDownload && !isUpdate_Spamtrap && !isUpdate_Invalid
              ? true
              : false
          }
        >
          Go!
        </button>
      </div>
    </div>
  );
};

export default Validate;
