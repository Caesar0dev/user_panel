import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";

import Loader from "react-loader-spinner";
import SocketClient from "../../utils/socketClient";
import Timer from "../timer";
// import "./style.css";
const Config = require("../../utils/config");
const AccountDetail = () => {
  const dispatch = useDispatch();
  const [email, setEamil] = useState("");
  const [response, setResponse] = useState({});
  useEffect(() => {}, []);
  const singleValidation = () => {
    fetch(
      `https://api.zerobounce.net/v2/validate?api_key=${Config.CONFIG.ZEROBOUNCE_KEY}&email=${email}&ip_address=`,
      {
        method: "GET",
        mode: "cors",
      }
    )
      .then((r) => r.json())
      .then((data) => {
        console.log("single validate ", data);
        setResponse(data);
      });
  };
  const onKeyPress = (e) => {
    if (e.which === 13) {
      alert(email);
    }
  };
  const socket = useSelector((state) => state.socket);

  // console.log("socket finish catch", socket);
  return (
    <div className="divSection">
      <div className="mt-2 box p-2">
        <b>Delete Account</b>
        <div className="box mt-4 row">
          <p style={{ fontSize: "15px" }}>
            Please note that if you delete your account all credit balances will
            be lost and subscriptions will cease immediately. No refunds will be
            made for unused credits or subscriptions.
          </p>

          <p>Account to be deleted: {socket.user.email}</p>
          <div className="col-sm-8">
            <input
              className="input"
              id="email"
              onChange={(e) => {
                setEamil(e.target.value);
              }}
              onKeyPress={onKeyPress}
            />
          </div>

          <div className="col-sm-4">
            <button className="button ml-1" onClick={singleValidation}>
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountDetail;
