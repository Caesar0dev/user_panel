import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
// import CheckIcon from "../styles/check.svg";
import ValidatingStatus from "../validatingStatus";
import Attention from "../../attention.png";
import CheckIcon from "../../tick.png";
import C1 from "../../logos/1.png";
import B1 from "../../logos/1-blue.png";

import C2 from "../../logos/2.png";
import B2 from "../../logos/2-blue.png";

import C3 from "../../logos/3.png";
import B3 from "../../logos/3-blue.png";

import C4 from "../../logos/4.png";
import B4 from "../../logos/4-blue.png";

import B5 from "../../logos/5-blue.png";
import C5 from "../../logos/5.png";
const Validating = () => {
  const dispatch = useDispatch();
  const [queued, setQueued] = useState(false);
  const [message, setMessage] = useState(
    "Email addresses have been extracted from Pipedrive"
  );
  const [status, setStatus] = useState(1);
  // zerobounce checking
  const [processing, setProcessing] = useState(false);
  const [greylist, setGreylist] = useState(false);
  const [reprocess, setReprocess] = useState(false);

  // updating pipedrive after zerobounce
  const [pipedrive, setPipedrive] = useState(false);
  const [finish, setFinish] = useState(false);
  const [current, setCurrent] = useState(localStorage.getItem("startTime"));
  const [finishTime, setFinishTime] = useState("in progress");
  const [progressText, setProcessText] = useState("in progress");
  const [uploaded, setUploaded] = useState(false);

  const GetTime = () => {
    var date, TimeType, hour, minutes, seconds, fullTime;
    // Creating Date() function object.
    date = new Date();

    // Getting current hour from Date object.
    hour = date.getHours();

    // Checking if the Hour is less than equals to 11 then Set the Time format as AM.
    if (hour <= 11) {
      TimeType = "AM";
    } else {
      // If the Hour is Not less than equals to 11 then Set the Time format as PM.
      TimeType = "PM";
    }

    // IF current hour is grater than 12 then minus 12 from current hour to make it in 12 Hours Format.
    if (hour > 12) {
      hour = hour - 12;
    }

    // If hour value is 0 then by default set its value to 12, because 24 means 0 in 24 hours time format.
    if (hour == 0) {
      hour = 12;
    }

    // Getting the current minutes from date object.
    minutes = date.getMinutes();

    // Checking if the minutes value is less then 10 then add 0 before minutes.
    if (minutes < 10) {
      minutes = "0" + minutes.toString();
    }
    fullTime =
      hour.toString() + ":" + minutes.toString() + ":" + TimeType.toString();
    console.log("time------->", fullTime);
    return fullTime;
  };
  const socket = useSelector((state) => state.socket);
  console.log("socket finish catch", socket);
  useEffect(() => {
    console.log("startTime", localStorage.getItem("startTime"));
    setCurrent(localStorage.getItem("startTime"));
    setTimeout(() => {
      setUploaded(true);
      setMessage("Email addresses have been uploaded to the server");
      setStatus(2);
    }, 5000);
  }, []);
  // if (socket.validateProcessing.status === "Processing") {
  //   if (!queued) {
  //     setQueued(true);
  //     setMessage("Email addresses have been uploaded to the server");
  //   }
  // } else if (socket.validateProcessing.status === "update_pipedrive") {
  //   if (!processing) {
  //     setProcessing(true);
  //     setMessage("Data has been uploaded to the server and is queued for processing")
  //   }
  // }

  if (socket.validateProcessing.status === "Processing" && !queued) {
    if (!uploaded) setUploaded(true);
    setTimeout(() => {
      setQueued(true);
      setMessage(
        "Email addresses have been uploaded to the server and are queued for processing"
      );
      setStatus(3);
    }, 5000);
    console.log("validatingStatus", status);
    //   setProcessing( socket.validateProcessing.percent)
  } else if (socket.validateProcessing.status === "update_pipedrive") {
    if (!uploaded) setUploaded(true);
    if (!queued) setQueued(true);
    if (!processing) {
      setTimeout(() => {
        setProcessing(true);
        setMessage("Email addresses have been validated");
        setStatus(4);
      }, 5000);
    }
    console.log("validatingStatus", status);
  }
  console.log("socket.stage", socket.stage);
  if (socket.stage == "validating" && !socket.validateProcessing) {
    if (!uploaded) {
      setTimeout(() => {
        setUploaded(true);
        setMessage("Email addresses have been uploaded to the server");
        setStatus(2);
      }, 5000);
    }
    console.log("validatingStatus", status);
  }
  if (socket.stage === "finished") {
    if (!uploaded) setUploaded(true);
    if (!queued) setQueued(true);
    if (!processing) setProcessing(true);
    if (!greylist) setGreylist(true);
    if (!reprocess) setReprocess(true);
    if (!pipedrive) {
      setPipedrive(true);
    }
    if (!finish) {
      setTimeout(() => {
        setProcessText("completed");
        setFinish(true);
        setFinishTime("at " + GetTime());
        setMessage("Pipedrive has been updated and/or results file downloaded");
        setStatus(5);
      }, 5000);
    }
    console.log("validatingStatus", status);
  }

  // if (socket.validateProcessing.status === "update_pipedrive") {
  //   setProcessing(true);
  //   setPipedrive(socket.validateProcessing.percent);
  // }

  return (
    <div className="mt-2 box p-2">
      <b className="page_heading">Bulk Email Validation </b>
      <br />
      <b className="sub_heading">Step 3</b>

      {socket.error !== "" && (
        <>
          <br /> <p style={{ color: "red" }}>{socket.error}</p>
        </>
      )}
      <br />
      <div className="d-flex">
        <div className="validateNote">
          {/* <p>Note:</p> */}
          <img src={Attention}></img>
        </div>
        <div className="validateComment">
          <p>
            You can leave this page and processing will continue. We will email
            you when processing is complete
          </p>
          <div>
            <div className="row">
              <div className="col-sm-5 col-logTime">
                <p>Email validation started: {current}</p>
              </div>
              <div className="col-sm-5 col-logTime">
                {" "}
                <p>
                  Email validation completed:{" "}
                  <span style={{ color: "red" }}>{finishTime}</span>
                </p>
              </div>
            </div>
            <div className="d-flex">
              <ValidatingStatus
                logoP={C1}
                logoD={B1}
                title={"Data Collected"}
                message={status == 1 ? message : ""}
                done={true}
              />
              <ValidatingStatus
                logoP={C2}
                logoD={B2}
                title={"Data uploaded"}
                message={status == 2 ? message : ""}
                done={uploaded}
              />
              <ValidatingStatus
                logoP={C3}
                logoD={B3}
                title={"Queued"}
                message={status == 3 ? message : ""}
                done={queued}
              />
              <ValidatingStatus
                logoP={C4}
                logoD={B4}
                title={"Validated"}
                message={status == 4 ? message : ""}
                done={processing}
              />
              <ValidatingStatus
                logoP={C5}
                logoD={B5}
                title={"Data updated"}
                message={status == 5 ? message : ""}
                done={finish}
              />
            </div>
            {/* <ValidatingStatus
          done={processing}
          status={
            processing
              ? "Processing"
              : `Processing(${socket.validateProcessing.percent})`
          }
        /> */}
            {/* {socket.validateProcessing.percent == "92%" ? (
          <ValidatingStatus
            done={processing}
            status={
              processing
                ? "Processing"
                : `Processing (${socket.validateProcessing.percent})-Waiting for greylist checking(approx20 mins)`
            }
          />
        ) : (
          <ValidatingStatus
            done={processing}
            status={
              processing
                ? "Processing"
                : `Processing (${socket.validateProcessing.percent})`
            }
          />
        )} */}
            {/* {processing ? (
          <ValidatingStatus
            done={pipedrive}
            status={
              pipedrive
                ? "Updating Pipedrive"
                : `Updating Pipedrive(${socket.validateProcessing.percent} %)`
            }
          />
        ) : (
          <ValidatingStatus done={pipedrive} status={"Updating Pipedrive"} />
        )} */}
          </div>
        </div>
      </div>
      <br />
    </div>
  );
};

export default Validating;
