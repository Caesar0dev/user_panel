import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";

import Loader from "react-loader-spinner";
import SocketClient from "../../utils/socketClient";
import Timer from "../timer";
// import "./style.css";
const Config = require("../../utils/config");
const Account = ({ handleCredit }) => {
  const dispatch = useDispatch();
  const [email, setEamil] = useState("");
  const [response, setResponse] = useState({});
  useEffect(() => {
    SocketClient.getInstance().send("status", {
      token: Config.CONFIG.PIPEDRIVE_API_TOKEN,
      id: socket.user.id,
      socket_id: localStorage.getItem("socket_id"),
      refresh_token: localStorage.getItem("refresh_token"),
    });
  }, []);
  const singleValidation = () => {
    fetch(
      `https://api.zerobounce.net/v2/validate?api_key=${Config.CONFIG.ZEROBOUNCE_KEY}&email=${email}&ip_address=`,
      {
        method: "GET",
        mode: "cors",
      }
    )
      .then((r) => r.json())
      .then((data) => {
        console.log("single validate ", data);
        setResponse(data);
      });
  };
  const onKeyPress = (e) => {
    if (e.which === 13) {
      alert(email);
    }
  };
  const revokeToken = () => {
    SocketClient.getInstance().send("revoke", {
      token: localStorage.getItem("access_token"),
      id: socket.user.id,
      socket_id: localStorage.getItem("socket_id"),
      refresh_token: localStorage.getItem("refresh_token"),
    });
  };
  const socket = useSelector((state) => state.socket);

  // console.log("socket finish catch", socket);
  return (
    <div className="divSection">
      <div className="mt-2 box p-2">
        <b className="page_heading">Account Details</b>
        <div className="box mt-4 row px-3">
          <div className="d-flex">
            <div className="w-30">
              <p className="accountSubInfo">Pipedrive User</p>
            </div>
            <div className="ml-3 w-60 ">
              <p>{socket.user.name}</p>
              <p>{socket.user.email}</p>
              <p>{socket.user.company_name}</p>
              <button
                onClick={revokeToken}
                style={{
                  color: "blue",
                  background: "transparent",
                  marginLeft: "-5px",
                }}
              >
                [revoke access]
              </button>
            </div>
          </div>
        </div>

        {/* <b>Credits</b> */}
        <div className="box mt-4 row px-3">
          <div className="d-flex">
            <div className="w-30">
              <p className="accountSubInfo">Available Credits</p>
            </div>
            <div className="ml-3 w-60">
              {SocketClient.getInstance().numberWithCommas(socket.credits)}
              <button
                onClick={handleCredit}
                style={{ color: "blue", background: "transparent" }}
              >
                [buy]
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
