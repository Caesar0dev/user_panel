import React, {Component} from 'react'
const Error =({props}) => {
    return (
          <p>
          </p>
    )
}
export default Error