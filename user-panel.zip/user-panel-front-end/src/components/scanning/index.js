import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import SocketClient from "../../utils/socketClient";
import Loader from "react-loader-spinner";
// import "./style.css";
import Validate from "../validate";
const Scanning = ({ idOfFilter }) => {
  const dispatch = useDispatch();
  const [scanedMail, setScanedMail] = useState(0);
  const [scanedPerson, setScanedPerson] = useState(0);
  const [totalPersons, setTotalPersons] = useState(0);
  useEffect(() => {
    if (socket.stage === "scanning") getPersonsByFilter(idOfFilter);
  }, []);

  const socket = useSelector((state) => state.socket);

  function getPersonsByFilter(filter) {
    let filter_id = filter ? "&filter_id=" + filter : "";
    fetch(
      `https://api.pipedrive.com/v1/persons?limit=1&get_summary=1` + filter_id,
      {
        method: "GET",
        mode: "cors",
        headers: {
          Authorization:
            "Bearer " +
            localStorage.getItem("access_token").toString().replace(/"/g, ""),
        },
      }
    )
      .then((r) => r.json())
      .then((data) => {
        console.log("get persons by filter", filter_id, data);
        if (data.additional_data)
          setTotalPersons(data.additional_data.summary.total_count);
        allPesonsEmails(0, idOfFilter);
      });
  }
  let scanStatus = {
    message: "starting scaning",
    scanned: 0,
    emails: 0,
    invalid_emails: 0,
  };

  let ignoredIds = {};
  let emails = {};
  let ids = [];
  let csv = "";
  let idToEmail = {};
  let invalid_emails = {};

  const scanSelected = () => {
    // state is scanning emails
    // alert(idOfFilter)

    emails = {};
    ignoredIds = {};
    idToEmail = {};

    ids = [];
    csv = "";
    invalid_emails = {};
    scanStatus = {
      message: "starting scanning",
      scanned: 0,
      emails: 0,
      invalid_emails: 0,
    };
    // console.log('start scan mail', { isSelected, isInverted });
    console.log("start scan mail", idOfFilter);
    allPesonsEmails(0, idOfFilter);
  };

  function allPesonsEmails(page = 0, filter) {
    console.log("allPesonsEmails", { page, filter });
    fetch(
      `https://api.pipedrive.com/v1/persons?filter_id=${filter}&start=${page}&limit=100`,
      {
        method: "GET",
        mode: "cors",
        headers: {
          Authorization:
            "Bearer " +
            localStorage.getItem("access_token").toString().replace(/"/g, ""),
        },
      }
    )
      .then((r) => r.json())
      .then((data) => {
        collectEmails(data.data);
        data.additional_data.pagination.more_items_in_collection
          ? allPesonsEmails(page + 100, filter)
          : finishScanning();
      })
      .catch((error) => {
        console.error("Error:", error);
        // chrome.storage.local.set({ state: "noEmailsFound" });
        console.log("noEmailFound");
      });
    // chrome.storage.local.set({
    //   scanning: `${scanStatus.scanned} persons scanned, ${scanStatus.emails} unique emails found`,
    // });
  }

  function collectEmails(data) {
    if (data != null && data[0]) {
      console.log("collectEmails", data);
      data.forEach((person) => {
        if (!ignoredIds[person.id]) {
          scanStatus.scanned++;
          setScanedPerson(scanStatus.scanned);
          if (person.email[0] && person.email[0].value) {
            idToEmail[person.id] = [];
            person.email.forEach((email) => {
              // Add valid email list
              if (email.value.indexOf(",") == -1) {
                idToEmail[person.id].push(email.value);

                if (!emails[email.value]) {
                  scanStatus.emails++;
                  setScanedMail(scanStatus.emails);
                  emails[email.value] = 1;

                  if (email.value.indexOf("(") > 0)
                    csv += `\n${email.value.substr(
                      0,
                      email.value.indexOf("(")
                    )},${person.first_name},${person.last_name}`;
                  else
                    csv += `\n${email.value},${person.first_name},${person.last_name}`;
                } else {
                  emails[email.value]++;
                }
              }
              // InValid Email
              else {
                if (!invalid_emails[email.value]) {
                  scanStatus.invalid_emails++;
                  invalid_emails[email.value] = 1;
                } else {
                  invalid_emails[email.value]++;
                }
              }
            });
          }
        }
      });
      console.log("emails", emails);
      console.log("idToEmail", idToEmail);

      // chrome.storage.local.set({
      //     scanning: `${scanStatus.scanned} persons scanned, ${scanStatus.emails} unique emails found`
      // });
      // scanStatus.message = `${scanStatus.scanned} persons scanned, ${scanStatus.emails} unique emails found`;
    }
  }
  const finishScanning = () => {
    setScanedPerson(scanStatus.scanned);
    setScanedMail(scanStatus.emails);
    console.log("scan finished", scanStatus.emails, scanStatus.scanned);
    console.log("scan scanedMail", scanedMail);

    setTimeout(function () {
      dispatch({
        type: "SET_VALIDATE",
        response: {
          scanned_persons: scanStatus.scanned,
          scanned_emails: scanStatus.emails,
          csv: csv,
          idToEmail: idToEmail,
          email: socket.user.email,
        },
      });
      dispatch({ type: "SET_STAGE", response: "scan_finished" });
    }, 1000);
    // chrome.storage.local.set({ state: 'success', stateData: csv });
  };
  const closeScanning = () => {
    dispatch({ type: "SET_STAGE", response: "scan_finished" });
  };
  return (
    <div>
      {/* stage is scan_finished, redirect to Validate page,
          if not, display the scanning result.
      */}
      {socket.stage === "scan_finished" ? (
        <Validate />
      ) : (
        <div className="blukSearching">
          <div style={{ display: "flex  " }}>
            {/* <h3 style={{ margin: "auto 20px " }}>Scanning</h3>{" "} */}
            {/* <Loader type="ThreeDots" color="#e07b12" height="80" width="80" /> */}
          </div>
          <div className="mt-4 box">
            <p>Searching for email addresses...</p>
          </div>

          <div className="mt-4 box">
            <div id="scanProgress">
              <div
                id="scanCompleted"
                style={{ width: (100 * scanedPerson) / totalPersons + "%" }}
              ></div>
            </div>
          </div>
          <div className="mt-4 box">
            <p>
              Contacts Searched:{" "}
              {SocketClient.getInstance().numberWithCommas(scanedPerson)}
            </p>
          </div>
          <div className="mt-4 box">
            <p>
              Unique emails:{" "}
              {SocketClient.getInstance().numberWithCommas(scanedMail)}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Scanning;
