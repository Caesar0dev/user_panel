import React, { Component, useEffect, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { bindActionCreators } from "redux";
import SocketClient from "../../utils/socketClient";
import "../styles/style.css";
import logo from "../../Web-Store-Logo.png";
const Operation = ({
  openBulkPage,
  openSinglePage,
  handleCredit,
  handleAccount,
  openProductExportPage,
  openProductImportPage,
}) => {
  const dispatch = useDispatch();
  const [amount, setAmount] = useState(1000);

  useEffect(() => {}, []);
  const socket = useSelector((state) => state.socket);

  const logout = () => {
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("user");
    localStorage.removeItem("access_token");
    localStorage.removeItem("status");
    window.location.reload();
  };

  return (
    <div className="divSection">
      <div>
        {/* <div className="mt-4 box">
          <a onClick={logout}>
            <button className="logoutButton" onClick={logout}>
              LOGOUT
            </button>
          </a>
        </div> */}
        <div className="mt-2 box p-2">
          <b>Pipedrive User</b>
          <p>{socket.user.name}</p>
          <p>{socket.user.email}</p>
        </div>
      </div>
      <div className="mt-2 box ">
        <a>
          <button className="sectionButton">My Account</button>
        </a>
        <br />
        <a>
          <button onClick={handleAccount}>Account Details</button>
        </a>
        {/* <br />
          <a>
            <button onClick={handleAccount}>Delete my account</button>
          </a> */}
      </div>
      <div className="mt-2 box">
        <a>
          <button className="sectionButton">Tools</button>
        </a>
        <a>
          <button onClick={openBulkPage}>Bulk email validation</button>
        </a>
        <br />
        <a>
          <button onClick={openSinglePage}>Single email validation</button>
        </a>
        <br />
        {/* <a>
          <button onClick={openProductExportPage}>Product Export</button>
        </a>
        <br />
        <a>
          <button onClick={openProductImportPage}>Product Import</button>
        </a> */}
        {/* <br />
        <a>
          <button onClick={openSinglePage}>Schedule email validation</button>
        </a> */}

        {/* 
        <div className="mt-2 box ">
          <a>
            <button className="sectionButton">Purchase Credits</button>
          </a>
          <br />
          <a>
            <button onClick={handleCredit}>Purchase Credits</button>
          </a>
        </div> */}

        <div className="browserExtensions">
          <a>
            <button className="sectionButton">Browser Extension</button>
          </a>
          <a
            href="https://chrome.google.com/webstore/detail/certalink-for-pipedrive/hfnlpioedibifjcphpjiljiabfcphoab"
            target="_blank"
          >
            <img src={logo}></img>
          </a>
        </div>
        {/* <a onClick={logout}> 
          <button className="sectionButton" onClick={handleCredit}>Logout</button>
        </a> */}
      </div>
    </div>
  );
};

export default Operation;
